function* say(name,chip,text)
{
  state.buildTextbox(name,text,chip);
  yield;
}
function* speak(mood,text)
{
  state.buildTextbox(caller.properties.name,text,caller.properties.name+"_"+mood);
  yield;
}
function* read(book,bookName,bookChip)
{
  var content = ctx.state.tilemap.properties[book].split("-");
  for (var i = 0;i < content.length;i++)
  {
    yield* say(bookName,bookChip,content[i].trim());
  }
}
class Periodic
{
  constructor(period,callback)
  {
    this.period = period;
    this.callback = callback;
    this.time = this.period;
  }
  update(elapsed)
  {
    this.time += elapsed;
    if (this.time >= this.period)
    {
      while (this.time >= this.period) this.time -= this.period;
      this.callback();
    }
  }
}
function getX() {return caller.body.x + caller.body.width / 2}
function getY() {return caller.y}
function getAngleToPlayer()
{
  return Math.atan2(state.player.y - getY(),state.player.x - getX());
}
function close(value,target,margin)
{
  return (value >= target - Math.abs(margin) && value <= target + Math.abs(margin));
}
function* wait(time)
{
  var elapsed = 0;
  while (elapsed < time)
  {
    elapsed += yield;
  }
  return elapsed - time;
}
function* waitAnimation(name)
{
  caller.animations.play(name);
  while (!caller.animations.currentAnim.isFinished) yield;
}
function* waitEffect(x,y,name,nFrames,framerate)
{
  var effect = state.addEffect(x,y,name,nFrames,framerate);
  while (effect.alive) yield;
}
function* waitMove(x,y)
{
  while (true)
  {
    var angle = Math.atan2(y - getY(),x - getX());
    caller.body.velocity.x = Math.cos(angle) * caller.properties.moveSpeed;
    caller.body.velocity.y = Math.sin(angle) * caller.properties.moveSpeed;
    yield* wait(50);
    if (close(getX(),x,caller.body.velocity.x) && close(getY(),y,caller.body.velocity.y)) return;
  }
}
function* waitRandomMove(time)
{
  var angle = Math.random() * Math.PI * 2 - Math.PI;
  caller.body.velocity.x = Math.sin(angle) * caller.properties.moveSpeed;
  caller.body.velocity.y = Math.cos(angle) * caller.properties.moveSpeed;
  yield* wait(time);
}
function* waitMoveNearPosition(time,x,y,maxDistance)
{
  var distance = Math.cos(Math.atan2(getY() - y,getX() - x)) * (getX() - x);
  if (distance < maxDistance)
  {
    var angle = Math.random() * Math.PI * 2 - Math.PI;
    caller.body.velocity.x = Math.sin(angle) * caller.properties.moveSpeed;
    caller.body.velocity.y = Math.cos(angle) * caller.properties.moveSpeed;
    yield* wait(time);
  }
  else
  {
    yield* waitMove(x,y);
  }
}
function* waitMoveToRegion(region)
{
  var region = state.regions[region];
  var x = region.x + region.width / 2;
  var y = region.y + region.height / 2;
  yield* waitMove(x,y);
}
function setSelfSwitch(name,value)
{
  ctx.setSwitch(ctx.state.tilemap.key+"-"+ctx.caller.name+"-"+name,value);
}
function getSelfSwitch(name)
{
  return ctx.getSwitch(ctx.state.tilemap.key+"-"+ctx.caller.name+"-"+name,value);
}
function compareArrays(a,b)
{
  if (a.length != b.length) return false;
  for (var i = 0 ;i < a.length;i++) if (a[i] != b[i]) return false;
  return true;
}
function createGun(x,y,key,moveSpeed=100,name="e")
{
  var data = {"key":key,"directional":false,"moveOnSpot":true,"health":1,
              "controller":"staticController.js","moveSpeed":moveSpeed};
  var gun = state.addDrone(x,y,name,{"properties":data});
  return gun;
}
function* moveGun(gun,x,y)
{
  while (true)
  {
    var angle = Math.atan2(y - gun.body.y,x - (gun.body.x + gun.body.width / 2));
    gun.body.velocity.x = Math.cos(angle) * gun.properties.moveSpeed;
    gun.body.velocity.y = Math.sin(angle) * gun.properties.moveSpeed;
    if (close((gun.body.x + gun.body.width / 2),x,gun.body.velocity.x) &&
        close(gun.body.y,y,gun.body.velocity.y))
    {
      gun.body.velocity.set(0);
      console.log("yee");
      return;
    }
    yield;
  }
}
var poisonBullets = state.createBulletGroup(caller,200,200,'poison','shot');
var cBullets = state.createBulletGroup(caller,120,60,'cBulletSmall','shot');
caller.animations.add("death",[8,9,10,11],4,false);
caller.animations.add("loseSpear",[12,13,14],3,false);
caller.animations.add("startPhone",[15,16,17],5,false);
caller.animations.add("onPhone",[18],4,true);
caller.animations.add("endPhone",[19,20,21],5,false);
function* traditionAttack()
{
  const N_TWISTS = 10;
  const TWIST_SIZE = 10;
  const TWIST_AMOUNT = 0.04;
  const TWIST_SPACING = 60;
  const TWIST_PAUSE = 600;
  for (var iteration = 0;true;iteration++)
  {
    for (var i = 0;i < TWIST_SIZE;i++)
    {
      for (var u = 0;u < N_TWISTS;u++) poisonBullets.fire(getX(),getY(),0,0,Math.PI * 2 / N_TWISTS * u + i * TWIST_AMOUNT * iteration);
      yield* wait(TWIST_SPACING);
    }
    yield* wait(TWIST_PAUSE);
  }
}
function* prongAttack()
{
  const N_GUNS = 2;
  const GUN_RADIUS = 300;
  const GAP = 400;
  caller.mode = Mode.NORMAL;
  yield* wait(1000);
  yield* speak("n","haha, wait until you see this");
  yield* waitAnimation("loseSpear");
  music.fadeOut(1000,Channel.Music);
  yield* say("Stasbangora Kebabom","stasbangoraKebabom_n","Huh? Your traditional spear?\nit's gone!");
  yield* wait(500);
  yield* waitAnimation("startPhone");
  caller.animations.play("onPhone");
  yield* wait(300);
  yield* speak("n","Send in the guns.");
  yield* wait(300);
  yield* waitAnimation("endPhone");
  var guns = [];
  var gunMovers = [];
  for (var i = 0;i < N_GUNS;i++)
  {
    guns[i] = createGun(getX(),getY(),"gun");
    var angle = (Math.PI * 2 / N_GUNS) * i - Math.PI;
    gunMovers[i] = moveGun(guns[i],getX() + GUN_RADIUS * Math.cos(angle),
                           getY() + GUN_RADIUS * Math.sin(angle));
  }
  var gunsFinished = 0;
  while (gunsFinished < N_GUNS)
  {
    var elapsed = yield;
    for (var i = gunMovers.length - 1;i >= 0;i--)
    {
      if (gunMovers[i].next(elapsed).done)
      {
        gunsFinished++;
        gunMovers.splice(i,1);
      }
    }
  }
  caller.mode = Mode.FIGHTING;
  music.playSong("firstBoss",Channel.Music);
  while (true)
  {
    for (var i = 0;i < N_GUNS;i++)
    {
      var angle = Math.atan2(state.player.y - guns[i].y,state.player.x - guns[i].x);
      cBullets.fire(guns[i].x,guns[i].y,0,0,angle);
    }
    yield* wait(GAP);
  }
}
caller.mode = Mode.FIGHTING;
controller.addState(600,traditionAttack);
controller.addState(450,prongAttack);
yield;
yield* waitAnimation("dead");
caller.dead = true
caller.properties.moveOnSpot = false;
ctx.setSwitch("centipedeDead",true);
while (true) yield;
