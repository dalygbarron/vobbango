Party
=====

This is a nice game about a party
