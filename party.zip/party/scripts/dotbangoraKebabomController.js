#include "std.js"
#include "gun.js"




/* definitions and that */
var poisonBullets = state.createBulletGroup(caller,200,200,'poison','shot');
var cBullets = state.createBulletGroup(caller,120,60,'cBulletSmall','shot');
caller.animations.add("death",[8,9,10,11],4,false);
caller.animations.add("loseSpear",[12,13,14],3,false);
caller.animations.add("startPhone",[15,16,17],5,false);
caller.animations.add("onPhone",[18],4,true);
caller.animations.add("endPhone",[19,20,21],5,false);


/* attacks */
function* traditionAttack()
{
  const N_TWISTS = 10;
  const TWIST_SIZE = 10;
  const TWIST_AMOUNT = 0.04;
  const TWIST_SPACING = 60;
  const TWIST_PAUSE = 600;

  for (var iteration = 0;true;iteration++)
  {
    for (var i = 0;i < TWIST_SIZE;i++)
    {
      for (var u = 0;u < N_TWISTS;u++) poisonBullets.fire(getX(),getY(),0,0,Math.PI * 2 / N_TWISTS * u + i * TWIST_AMOUNT * iteration);
      yield* wait(TWIST_SPACING);
    }
    yield* wait(TWIST_PAUSE);
  }
}


function* prongAttack()
{
  const N_GUNS = 2;
  const GUN_RADIUS = 300;
  const GAP = 400;


  caller.mode = Mode.NORMAL;
  yield* wait(1000);
  yield* speak("n","haha, wait until you see this");
  yield* waitAnimation("loseSpear");
  music.fadeOut(1000,Channel.Music);
  yield* say("Stasbangora Kebabom","stasbangoraKebabom_n","Huh? Your traditional spear?\nit's gone!");
  yield* wait(500);
  yield* waitAnimation("startPhone");
  caller.animations.play("onPhone");
  yield* wait(300);
  yield* speak("n","Send in the guns.");
  yield* wait(300);
  yield* waitAnimation("endPhone");


  var guns = [];
  var gunMovers = [];
  for (var i = 0;i < N_GUNS;i++)
  {
    guns[i] = createGun(getX(),getY(),"gun");
    var angle = (Math.PI * 2 / N_GUNS) * i - Math.PI;
    gunMovers[i] = moveGun(guns[i],getX() + GUN_RADIUS * Math.cos(angle),
                           getY() + GUN_RADIUS * Math.sin(angle));
  }

  var gunsFinished = 0;
  while (gunsFinished < N_GUNS)
  {
    var elapsed = yield;
    for (var i = gunMovers.length - 1;i >= 0;i--)
    {
      if (gunMovers[i].next(elapsed).done)
      {
        gunsFinished++;
        gunMovers.splice(i,1);
      }
    }
  }



  caller.mode = Mode.FIGHTING;
  music.playSong("firstBoss",Channel.Music);

  while (true)
  {
    for (var i = 0;i < N_GUNS;i++)
    {
      var angle = Math.atan2(state.player.y - guns[i].y,state.player.x - guns[i].x);
      cBullets.fire(guns[i].x,guns[i].y,0,0,angle);
    }
    yield* wait(GAP);
  }
}


caller.mode = Mode.FIGHTING;
controller.addState(600,traditionAttack);
controller.addState(450,prongAttack);
yield;



yield* waitAnimation("dead");
caller.dead = true
caller.properties.moveOnSpot = false;
ctx.setSwitch("centipedeDead",true);
while (true) yield;
