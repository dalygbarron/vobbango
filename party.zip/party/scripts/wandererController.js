#include "std.js"
while (true) yield* waitRandomMove(Math.random() * 1000);
