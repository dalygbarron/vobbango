ok so there will be these kinda layers, and you have to go through increasingly nasty
ones until you are somehow on the other side and free
The Layers will be:
 - you are at a party and you have to avoid the lights
 - people are launching eyeballs at you
 - some lady is launching strange images at you
 - everyone turns into immolated corpses, and blood is getting launched at you by the lady
   plus more weird images and whatever I feel like

yeah ok that'll do
